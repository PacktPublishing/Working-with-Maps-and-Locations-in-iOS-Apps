//
//  CoreDataHelper.swift
//  PokemonGoClone
//
//  Created by zappycode on 6/6/18.
//  Copyright © 2018 Nick Walter. All rights reserved.
//

import CoreData
import UIKit

func addAllPokemon() {
    createPokemon(name: "Pikachu", imageName: "pikachu-2")
    createPokemon(name: "Abra", imageName: "abra")
    createPokemon(name: "Bullbasaur", imageName: "bullbasaur")
    createPokemon(name: "Caterpie", imageName: "caterpie")
}

func createPokemon(name:String,imageName:String) {
    if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
        let pokemon = Pokemon(context: context)
        pokemon.name = name
        pokemon.imageName = imageName
        pokemon.caught = false
        try? context.save()
    }
}

func getAllPokemon() -> [Pokemon] {
    if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
        if let pokeData = try?  context.fetch(Pokemon.fetchRequest()) as? [Pokemon] {
            if let pokemons = pokeData {
                if pokemons.count == 0 {
                    addAllPokemon()
                    return getAllPokemon()
                } else {
                    return pokemons
                }
            }
        }
    }
    return []
}
