//
//  PokeAnnotation.swift
//  PokemonGoClone
//
//  Created by zappycode on 6/6/18.
//  Copyright © 2018 Nick Walter. All rights reserved.
//

import UIKit
import MapKit

class PokeAnnotation : NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var pokemon : Pokemon
    
    init(coord:CLLocationCoordinate2D, pokemon:Pokemon) {
        self.coordinate = coord
        self.pokemon = pokemon
    }
}
